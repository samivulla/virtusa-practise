import { AgecalculateDirective } from './agecalculate.directive';

describe('AgecalculateDirective', () => {
  it('should create an instance', () => {
    const directive = new AgecalculateDirective();
    expect(directive).toBeTruthy();
  });
});
